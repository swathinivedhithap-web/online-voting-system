<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign in · Ballot</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css">
</head>
<body>
<div class="shell">
  <header class="topbar"><div class="topbar-inner">
    <a class="brand" href="${pageContext.request.contextPath}/"><span class="brand-mark">B</span><span class="brand-copy"><strong>Ballot</strong><span>Online Voting System · Tomcat demo</span></span></a>
    <nav class="nav"><a class="nav-link active" href="${pageContext.request.contextPath}/">Sign in</a><a class="nav-link" href="${pageContext.request.contextPath}/results">Public results</a></nav>
  </div></header>
  <main class="main">
    <div class="page-heading"><div><p class="eyebrow">Secure participation · Local demo</p><h1>Welcome to Ballot</h1><p class="subheading">Sign in to cast a ballot or review public election results.</p></div></div>
    <c:if test="${not empty loginError}"><div class="notice error" role="alert"><c:out value="${loginError}"/></div></c:if>
    <section class="login-wrap panel">
      <div class="tabs" role="tablist" aria-label="Choose account type">
        <button class="tab active" type="button" role="tab" aria-selected="true" data-tab="voter-panel">Voter</button>
        <button class="tab" type="button" role="tab" aria-selected="false" data-tab="admin-panel">Admin</button>
      </div>
      <section id="voter-panel" class="tab-panel">
        <h2>Voter sign in</h2><p class="subheading">Your voter ID, password, and demo identity number are required.</p>
        <form action="${pageContext.request.contextPath}/login" method="post">
          <input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="role" value="VOTER">
          <div class="field"><label for="voterId">Voter ID</label><input id="voterId" name="username" maxlength="80" autocomplete="username" required></div>
          <div class="field"><label for="identityNumber">Demo identity number</label><input id="identityNumber" name="identityNumber" inputmode="numeric" pattern="[0-9]{12}" maxlength="12" placeholder="12 digits" autocomplete="off" required><p class="help">Prototype only. Do not enter a real Aadhaar number. It is not checked with UIDAI.</p></div>
          <div class="field"><label for="voterPassword">Password</label><input id="voterPassword" name="password" type="password" maxlength="200" autocomplete="current-password" required></div>
          <button class="button full-width" type="submit">Continue to voter dashboard</button>
        </form>
      </section>
      <section id="admin-panel" class="tab-panel" hidden>
        <h2>Administrator sign in</h2><p class="subheading">Manage voters, candidates, and elections.</p>
        <form action="${pageContext.request.contextPath}/login" method="post">
          <input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="role" value="ADMIN">
          <div class="field"><label for="adminUsername">Username</label><input id="adminUsername" name="username" autocomplete="username" required></div>
          <div class="field"><label for="adminPassword">Password</label><input id="adminPassword" name="password" type="password" maxlength="200" autocomplete="current-password" required></div>
          <button class="button full-width" type="submit">Sign in as admin</button>
          <p class="help demo-credentials">Initial demo login: <strong>admin / admin123</strong>. Change this before exposing the app to any network.</p>
        </form>
      </section>
    </section>
    <div class="alert"><strong>Prototype, not a real election:</strong> Identity numbers are only format-checked and compared with a locally registered demo value; there is no government identity verification. Use mock data only. See the project README for limitations.</div>
  </main>
  <footer class="footer"><div class="footer-inner">Ballot local demonstration · Apache Tomcat 10.1 · Java 17</div></footer>
</div>
<script>
  document.querySelectorAll("[data-tab]").forEach((tab) => tab.addEventListener("click", () => {
    document.querySelectorAll("[data-tab]").forEach((item) => {
      const active = item === tab;
      item.classList.toggle("active", active);
      item.setAttribute("aria-selected", String(active));
    });
    document.querySelectorAll(".tab-panel").forEach((panel) => panel.hidden = panel.id !== tab.dataset.tab);
  }));
</script>
</body>
</html>
