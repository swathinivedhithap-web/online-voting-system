<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin dashboard · Ballot</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css"></head>
<body><div class="shell">
  <header class="topbar"><div class="topbar-inner">
    <a class="brand" href="${pageContext.request.contextPath}/admin"><span class="brand-mark">B</span><span class="brand-copy"><strong>Ballot</strong><span>Online Voting System · Admin</span></span></a>
    <nav class="nav"><a class="nav-link active" href="${pageContext.request.contextPath}/admin">Admin panel</a><a class="nav-link" href="${pageContext.request.contextPath}/results">Public results</a><form action="${pageContext.request.contextPath}/logout" method="post"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><button class="nav-link" type="submit">Sign out</button></form></nav>
  </div></header>
  <main class="main">
    <div class="page-heading"><div><p class="eyebrow">Election administration</p><h1>Admin panel</h1><p class="subheading">Manage voters, elections, candidates, and live results.</p></div></div>
    <c:if test="${not empty flashMessage}"><div class="notice ${flashType}" role="status"><c:out value="${flashMessage}"/></div></c:if>
    <div class="grid three metrics"><div class="metric"><span>Registered voters</span><strong><c:out value="${voterCount}"/></strong></div><div class="metric"><span>Open elections</span><strong><c:out value="${openElectionCount}"/></strong></div><div class="metric"><span>Total ballots</span><strong><c:out value="${totalBallots}"/></strong></div></div>
    <div class="stack">
      <section class="panel"><div class="section-heading"><div><h2>Register eligible voter</h2><p>Voters must be at least 18. Identity number is locally hashed and is not UIDAI verified.</p></div></div>
        <form action="${pageContext.request.contextPath}/admin" method="post"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="action" value="register-voter">
          <div class="form-grid">
            <div class="field"><label for="voterId">Voter ID</label><input id="voterId" name="voterId" maxlength="80" required></div><div class="field"><label for="fullName">Full name</label><input id="fullName" name="fullName" maxlength="120" required></div>
            <div class="field"><label for="dateOfBirth">Date of birth</label><input id="dateOfBirth" name="dateOfBirth" type="date" required></div>
            <div class="field"><label for="identityNumber">Demo identity number</label><input id="identityNumber" name="identityNumber" inputmode="numeric" pattern="[0-9]{12}" maxlength="12" required><p class="help">Use mock data only; never enter a real Aadhaar number.</p></div>
            <div class="field full"><label for="password">Temporary password</label><input id="password" name="password" type="password" minlength="10" maxlength="200" autocomplete="new-password" required><p class="help">At least 10 characters. Passwords are salted and hashed.</p></div>
          </div><div class="form-actions"><button class="button" type="submit">Register voter</button></div>
        </form>
      </section>
      <section class="panel"><div class="section-heading"><div><h2>Voter directory</h2><p>Status shows the number of elections each voter has voted in. Identity numbers are never displayed.</p></div></div>
        <c:choose><c:when test="${empty voters}"><div class="empty">No voters registered.</div></c:when><c:otherwise><div class="table-wrap"><table><thead><tr><th>Name</th><th>Voter ID</th><th>DOB</th><th>Identity</th><th>Status</th><th></th></tr></thead><tbody>
          <c:forEach var="voter" items="${voters}"><tr><td><strong><c:out value="${voter.fullName}"/></strong></td><td><c:out value="${voter.username}"/></td><td><c:out value="${voter.dateOfBirth}"/></td><td>[Redacted]</td><td><c:choose><c:when test="${not empty voter.votedElectionIds}"><span class="badge voted">Voted · <c:out value="${voter.votedElectionIds.size()}"/></span></c:when><c:otherwise><span class="badge pending">Not voted</span></c:otherwise></c:choose></td><td>
            <c:if test="${empty voter.votedElectionIds}"><form action="${pageContext.request.contextPath}/admin" method="post" onsubmit="return confirm('Remove this voter?')"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="action" value="remove-voter"><input type="hidden" name="voterId" value="<c:out value='${voter.id}'/>"><button class="button danger small" type="submit">Remove</button></form></c:if>
          </td></tr></c:forEach>
        </tbody></table></div></c:otherwise></c:choose>
      </section>
      <section class="panel"><div class="section-heading"><div><h2>Create election</h2><p>New elections open immediately. Register candidates before ballots are cast.</p></div></div>
        <form action="${pageContext.request.contextPath}/admin" method="post"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="action" value="create-election">
          <div class="form-grid"><div class="field full"><label for="title">Election name</label><input id="title" name="title" maxlength="140" placeholder="Student Council President 2026" required></div><div class="field full"><label for="description">Description</label><textarea id="description" name="description" maxlength="500"></textarea></div></div>
          <div class="form-actions"><button class="button" type="submit">Create election</button></div>
        </form>
      </section>
      <section class="panel"><div class="section-heading"><div><h2>Elections and live results</h2><p>Results are updated from recorded ballots. Candidate changes lock after the first vote.</p></div></div>
        <c:choose><c:when test="${empty elections}"><div class="empty">Create an election above to get started.</div></c:when><c:otherwise><div class="stack">
          <c:forEach var="election" items="${elections}"><article class="card election-card">
            <div class="election-title-row"><div><h3><c:out value="${election.title}"/></h3><p><c:out value="${election.description}"/></p></div><c:choose><c:when test="${election.active}"><span class="badge open">Open</span></c:when><c:otherwise><span class="badge closed">Closed</span></c:otherwise></c:choose></div>
            <p class="muted small-text"><c:out value="${election.totalVotes}"/> ballots · turnout <c:out value="${election.turnout}"/> / <c:out value="${election.eligibleVoters}"/> (<fmt:formatNumber value="${election.turnoutPercent}" maxFractionDigits="1"/>%)</p>
            <div class="candidate-list">
              <c:forEach var="candidate" items="${election.candidates}"><div class="candidate"><div class="candidate-info"><strong><c:out value="${candidate.name}"/></strong><span><c:out value="${candidate.party}"/> · <c:out value="${candidate.votes}"/> vote(s)</span></div>
                <c:if test="${election.totalVotes == 0}"><form action="${pageContext.request.contextPath}/admin" method="post" onsubmit="return confirm('Remove this candidate?')"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="action" value="remove-candidate"><input type="hidden" name="electionId" value="<c:out value='${election.id}'/>"><input type="hidden" name="candidateId" value="<c:out value='${candidate.id}'/>"><button class="button danger small" type="submit">Remove</button></form></c:if>
              </div></c:forEach>
            </div>
            <c:if test="${election.active and election.totalVotes == 0}"><form class="subsection" action="${pageContext.request.contextPath}/admin" method="post"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="action" value="add-candidate"><input type="hidden" name="electionId" value="<c:out value='${election.id}'/>">
              <div class="form-grid"><div class="field"><label>Candidate name</label><input name="candidateName" maxlength="100" required></div><div class="field"><label>Party / affiliation</label><input name="party" maxlength="100"></div><div class="field full"><label>Details</label><textarea name="details" maxlength="500"></textarea></div></div><div class="form-actions"><button class="button small" type="submit">Add candidate</button></div>
            </form></c:if>
            <c:if test="${not empty election.candidates}"><div class="subsection"><h3>Vote share</h3><c:forEach var="candidate" items="${election.candidates}"><div class="progress-block"><div class="progress-label"><strong><c:out value="${candidate.name}"/></strong><span><c:out value="${candidate.votes}"/> · <fmt:formatNumber value="${election.getPercent(candidate)}" maxFractionDigits="1"/>%</span></div><div class="progress-track"><div class="progress-fill" style="width:<c:out value='${election.getPercent(candidate)}'/>%"></div></div></div></c:forEach>
              <c:if test="${election.totalVotes gt 0 and not empty election.leader}"><div class="winner"><c:choose><c:when test="${election.tiedForLead}">Currently tied at the lead.</c:when><c:otherwise>Currently leading: <strong><c:out value="${election.leader.name}"/></strong></c:otherwise></c:choose></div></c:if></div></c:if>
            <form action="${pageContext.request.contextPath}/admin" method="post" class="form-actions"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="action" value="toggle-election"><input type="hidden" name="electionId" value="<c:out value='${election.id}'/>"><button class="button secondary small" type="submit"><c:choose><c:when test="${election.active}">Close election</c:when><c:otherwise>Reopen election</c:otherwise></c:choose></button></form>
          </article></c:forEach>
        </div></c:otherwise></c:choose>
      </section>
    </div>
  </main>
  <footer class="footer"><div class="footer-inner">Local demo only · Do not use for a real election or real Aadhaar data.</div></footer>
</div></body></html>
