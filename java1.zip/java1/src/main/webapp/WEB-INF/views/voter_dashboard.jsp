<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Voter dashboard · Ballot</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css"></head>
<body><div class="shell">
  <header class="topbar"><div class="topbar-inner">
    <a class="brand" href="${pageContext.request.contextPath}/voter"><span class="brand-mark">B</span><span class="brand-copy"><strong>Ballot</strong><span>Online Voting System · Voter</span></span></a>
    <nav class="nav"><a class="nav-link active" href="${pageContext.request.contextPath}/voter">My ballot</a><a class="nav-link" href="${pageContext.request.contextPath}/results">Public results</a>
      <form action="${pageContext.request.contextPath}/logout" method="post"><input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><button class="nav-link" type="submit">Sign out</button></form>
    </nav>
  </div></header>
  <main class="main">
    <div class="page-heading"><div><p class="eyebrow">Eligible voter</p><h1>Your voter dashboard</h1><p class="subheading">Review open elections and submit one ballot per election.</p></div></div>
    <div class="signed-in"><div><strong>Signed in as <c:out value="${sessionScope.user.fullName}"/></strong><span>Voter ID: <c:out value="${sessionScope.user.username}"/> · Identity number: [Redacted]</span></div></div>
    <c:if test="${not empty flashMessage}"><div class="notice ${flashType}" role="status"><c:out value="${flashMessage}"/></div></c:if>
    <c:choose><c:when test="${empty elections}"><div class="empty"><strong>No elections available</strong>Check back when the administrator opens an election.</div></c:when><c:otherwise>
      <div class="stack">
        <c:forEach var="election" items="${elections}">
          <section class="card election-card">
            <div class="election-title-row"><div><h2><c:out value="${election.title}"/></h2><p><c:out value="${election.description}"/></p></div>
              <c:choose><c:when test="${election.voterHasVoted}"><span class="badge voted">You have voted</span></c:when><c:when test="${election.active}"><span class="badge open">Open</span></c:when><c:otherwise><span class="badge closed">Closed</span></c:otherwise></c:choose>
            </div>
            <c:if test="${election.voterHasVoted}"><div class="receipt"><strong>Ballot submitted</strong><span>Your participation is recorded. Your selection is kept secret.</span></div></c:if>
            <c:choose><c:when test="${empty election.candidates}"><div class="empty">No candidates have been registered for this election.</div></c:when><c:otherwise>
              <div class="candidate-list"><c:forEach var="candidate" items="${election.candidates}">
                <div class="candidate"><div class="candidate-info"><strong><c:out value="${candidate.name}"/></strong><span><c:out value="${candidate.party}"/><c:if test="${not empty candidate.details}"> · <c:out value="${candidate.details}"/></c:if></span></div>
                  <c:if test="${election.active and not election.voterHasVoted}">
                    <form action="${pageContext.request.contextPath}/vote" method="post" class="vote-form">
                      <input type="hidden" name="csrfToken" value="<c:out value='${csrfToken}'/>"><input type="hidden" name="electionId" value="<c:out value='${election.id}'/>"><input type="hidden" name="candidateId" value="<c:out value='${candidate.id}'/>">
                      <button class="button small" type="submit">Vote for candidate</button>
                    </form>
                  </c:if>
                </div>
              </c:forEach></div>
            </c:otherwise></c:choose>
            <div class="result-summary"><div class="section-heading"><div><h3>Live results</h3><p><c:out value="${election.totalVotes}"/> ballots · turnout <c:out value="${election.turnout}"/> / <c:out value="${election.eligibleVoters}"/> (<c:out value="${election.turnoutPercent}"/>%)</p></div></div>
              <c:forEach var="candidate" items="${election.candidates}"><div class="progress-block"><div class="progress-label"><strong><c:out value="${candidate.name}"/></strong><span><c:out value="${candidate.votes}"/> · <fmt:formatNumber value="${election.getPercent(candidate)}" maxFractionDigits="1"/>%</span></div><div class="progress-track"><div class="progress-fill" style="width:<c:out value='${election.getPercent(candidate)}'/>%"></div></div></div></c:forEach>
            </div>
          </section>
        </c:forEach>
      </div>
    </c:otherwise></c:choose>
  </main>
  <footer class="footer"><div class="footer-inner">Demo only. Local identity check is not Aadhaar/UIDAI verification.</div></footer>
</div></body></html>
