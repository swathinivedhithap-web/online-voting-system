<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Public results · Ballot</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/app.css"></head>
<body><div class="shell">
  <header class="topbar"><div class="topbar-inner"><a class="brand" href="${pageContext.request.contextPath}/"><span class="brand-mark">B</span><span class="brand-copy"><strong>Ballot</strong><span>Online Voting System · Public results</span></span></a><nav class="nav"><a class="nav-link" href="${pageContext.request.contextPath}/">Sign in</a><a class="nav-link active" href="${pageContext.request.contextPath}/results">Results</a></nav></div></header>
  <main class="main"><div class="page-heading"><div><p class="eyebrow">Public results</p><h1>Election results</h1><p class="subheading">Live vote totals, candidate percentages, and voter turnout.</p></div></div>
    <c:choose><c:when test="${empty elections}"><div class="empty"><strong>No elections yet</strong>Results will appear after an administrator creates an election.</div></c:when><c:otherwise><div class="stack"><c:forEach var="election" items="${elections}">
      <section class="card election-card"><div class="election-title-row"><div><h2><c:out value="${election.title}"/></h2><p><c:out value="${election.description}"/></p></div><c:choose><c:when test="${election.active}"><span class="badge open">Open</span></c:when><c:otherwise><span class="badge closed">Closed</span></c:otherwise></c:choose></div>
        <p class="muted small-text"><c:out value="${election.totalVotes}"/> ballots · turnout <c:out value="${election.turnout}"/> / <c:out value="${election.eligibleVoters}"/> (<fmt:formatNumber value="${election.turnoutPercent}" maxFractionDigits="1"/>%)</p>
        <c:choose><c:when test="${empty election.candidates}"><div class="empty">No candidates registered.</div></c:when><c:otherwise>
          <div class="candidate-list"><c:forEach var="candidate" items="${election.candidates}"><div class="progress-block"><div class="progress-label"><strong><c:out value="${candidate.name}"/> <c:if test="${not empty candidate.party}">· <c:out value="${candidate.party}"/></c:if></strong><span><c:out value="${candidate.votes}"/> votes · <fmt:formatNumber value="${election.getPercent(candidate)}" maxFractionDigits="1"/>%</span></div><div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<fmt:formatNumber value='${election.getPercent(candidate)}' maxFractionDigits='1'/>"><div class="progress-fill" style="width:<c:out value='${election.getPercent(candidate)}'/>%"></div></div></div></c:forEach></div>
          <c:if test="${election.totalVotes gt 0 and not empty election.leader}"><div class="winner"><c:choose><c:when test="${election.tiedForLead}">Currently tied at the lead.</c:when><c:otherwise>Currently leading: <strong><c:out value="${election.leader.name}"/></strong></c:otherwise></c:choose></div></c:if>
        </c:otherwise></c:choose>
      </section>
    </c:forEach></div></c:otherwise></c:choose>
  </main><footer class="footer"><div class="footer-inner">Public results · Local demonstration data</div></footer>
</div></body></html>
