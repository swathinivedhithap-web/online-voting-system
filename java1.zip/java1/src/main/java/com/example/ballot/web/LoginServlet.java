package com.example.ballot.web;

import com.example.ballot.db.Database;
import com.example.ballot.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/login")
public final class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String role = Web.value(request, "role", 10);
            String username = Web.value(request, "username", 80);
            String password = request.getParameter("password");
            String identity = request.getParameter("identityNumber");
            if (!"ADMIN".equals(role) && !"VOTER".equals(role)) {
                request.setAttribute("loginError", "Choose a valid sign-in type.");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                return;
            }
            if (username.isBlank() || password == null || password.length() > 200) {
                request.setAttribute("loginError", "Enter a valid username and password.");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                return;
            }
            if ("VOTER".equals(role) && (identity == null || !identity.matches("\\d{12}"))) {
                request.setAttribute("loginError", "Enter the 12-digit demo identity number.");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                return;
            }
            User user = Database.authenticate(username, password, "VOTER".equals(role) ? identity : null);
            if (user == null || !role.equals(user.getRole())) {
                request.setAttribute("loginError", "Sign-in failed. Check your credentials, demo identity number, and eligibility.");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                return;
            }
            request.changeSessionId();
            request.getSession().setAttribute("user", user);
            if (user.isAdmin()) response.sendRedirect(request.getContextPath() + "/admin");
            else response.sendRedirect(request.getContextPath() + "/voter");
        } catch (IllegalArgumentException ex) {
            request.setAttribute("loginError", ex.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
        } catch (Exception ex) {
            throw new ServletException("Unable to authenticate.", ex);
        }
    }
}
