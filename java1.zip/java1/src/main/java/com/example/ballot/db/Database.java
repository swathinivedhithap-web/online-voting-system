package com.example.ballot.db;

import com.example.ballot.model.Candidate;
import com.example.ballot.model.Election;
import com.example.ballot.model.User;
import com.example.ballot.model.Voter;
import com.example.ballot.security.PasswordUtil;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class Database {
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";
    private static String jdbcUrl;

    private Database() { }

    public static void initialize() throws Exception {
        Class.forName("org.h2.Driver");
        String configuredPath = System.getProperty("ballot.db.path");
        Path dbFile = configuredPath == null || configuredPath.isBlank()
                ? Path.of(System.getProperty("user.home"), ".ballot-demo", "voting")
                : Path.of(configuredPath);
        Path parent = dbFile.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        jdbcUrl = "jdbc:h2:file:" + dbFile.toAbsolutePath().toString().replace('\\', '/')
                + ";DB_CLOSE_ON_EXIT=FALSE;DATABASE_TO_UPPER=FALSE";

        try (Connection connection = getConnection(); Statement statement = connection.createStatement()) {
            statement.execute("""
                CREATE TABLE IF NOT EXISTS users (
                  id VARCHAR(36) PRIMARY KEY,
                  username VARCHAR(80) NOT NULL UNIQUE,
                  full_name VARCHAR(120) NOT NULL,
                  date_of_birth DATE,
                  role VARCHAR(10) NOT NULL CHECK (role IN ('ADMIN', 'VOTER')),
                  password_salt VARCHAR(100) NOT NULL,
                  password_hash VARCHAR(100) NOT NULL,
                  identity_salt VARCHAR(100),
                  identity_hash VARCHAR(100),
                  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                )
                """);
            statement.execute("""
                CREATE TABLE IF NOT EXISTS elections (
                  id VARCHAR(36) PRIMARY KEY,
                  title VARCHAR(140) NOT NULL,
                  description VARCHAR(500) NOT NULL,
                  active BOOLEAN NOT NULL DEFAULT TRUE,
                  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
                )
                """);
            statement.execute("""
                CREATE TABLE IF NOT EXISTS candidates (
                  id VARCHAR(36) PRIMARY KEY,
                  election_id VARCHAR(36) NOT NULL REFERENCES elections(id),
                  name VARCHAR(100) NOT NULL,
                  party VARCHAR(100) NOT NULL,
                  details VARCHAR(500) NOT NULL
                )
                """);
            statement.execute("""
                CREATE TABLE IF NOT EXISTS votes (
                  id VARCHAR(36) PRIMARY KEY,
                  election_id VARCHAR(36) NOT NULL REFERENCES elections(id),
                  candidate_id VARCHAR(36) NOT NULL REFERENCES candidates(id),
                  voter_id VARCHAR(36) NOT NULL REFERENCES users(id),
                  receipt VARCHAR(40) NOT NULL UNIQUE,
                  cast_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  CONSTRAINT one_vote_per_election UNIQUE (election_id, voter_id)
                )
                """);
            seedAdmin(connection);
        }
    }

    private static Connection getConnection() throws SQLException {
        if (jdbcUrl == null) throw new SQLException("The voting database has not been initialized.");
        return DriverManager.getConnection(jdbcUrl, "sa", "");
    }

    private static void seedAdmin(Connection connection) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement("SELECT id FROM users WHERE username = ?")) {
            query.setString(1, "admin");
            try (ResultSet rs = query.executeQuery()) {
                if (rs.next()) return;
            }
        }
        String salt = PasswordUtil.newSalt();
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO users (id, username, full_name, role, password_salt, password_hash)
                VALUES (?, 'admin', 'System Administrator', 'ADMIN', ?, ?)
                """)) {
            insert.setString(1, UUID.randomUUID().toString());
            insert.setString(2, salt);
            insert.setString(3, PasswordUtil.hash(DEFAULT_ADMIN_PASSWORD, salt));
            insert.executeUpdate();
        }
    }

    public static User authenticate(String username, String password, String identityNumber) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement query = connection.prepareStatement("""
                 SELECT id, username, full_name, date_of_birth, role, password_salt, password_hash,
                        identity_salt, identity_hash
                 FROM users WHERE LOWER(username) = LOWER(?)
                 """)) {
            query.setString(1, username.trim());
            try (ResultSet rs = query.executeQuery()) {
                if (!rs.next() || !PasswordUtil.matches(password, rs.getString("password_salt"), rs.getString("password_hash"))) {
                    return null;
                }
                String role = rs.getString("role");
                if ("ADMIN".equals(role)) {
                    return new User(rs.getString("id"), rs.getString("username"), rs.getString("full_name"), "ADMIN") { };
                }
                String identitySalt = rs.getString("identity_salt");
                String identityHash = rs.getString("identity_hash");
                if (identityNumber == null || !PasswordUtil.matches(identityNumber, identitySalt, identityHash)) return null;
                LocalDate dob = rs.getDate("date_of_birth").toLocalDate();
                if (Period.between(dob, LocalDate.now()).getYears() < 18) return null;
                return new Voter(rs.getString("id"), rs.getString("username"), rs.getString("full_name"), dob,
                        getVotedElectionIds(connection, rs.getString("id")));
            }
        }
    }

    private static Set<String> getVotedElectionIds(Connection connection, String voterId) throws SQLException {
        Set<String> result = new HashSet<>();
        try (PreparedStatement query = connection.prepareStatement("SELECT election_id FROM votes WHERE voter_id = ?")) {
            query.setString(1, voterId);
            try (ResultSet rs = query.executeQuery()) {
                while (rs.next()) result.add(rs.getString(1));
            }
        }
        return result;
    }

    public static void registerVoter(String voterId, String name, LocalDate dob, String demoIdentity, String password)
            throws SQLException {
        if (Period.between(dob, LocalDate.now()).getYears() < 18) throw new IllegalArgumentException("Voter must be at least 18 years old.");
        String passwordSalt = PasswordUtil.newSalt();
        String identitySalt = PasswordUtil.newSalt();
        try (Connection connection = getConnection();
             PreparedStatement insert = connection.prepareStatement("""
                 INSERT INTO users (id, username, full_name, date_of_birth, role, password_salt, password_hash,
                                    identity_salt, identity_hash)
                 VALUES (?, ?, ?, ?, 'VOTER', ?, ?, ?, ?)
                 """)) {
            insert.setString(1, UUID.randomUUID().toString());
            insert.setString(2, voterId.trim());
            insert.setString(3, name.trim());
            insert.setDate(4, java.sql.Date.valueOf(dob));
            insert.setString(5, passwordSalt);
            insert.setString(6, PasswordUtil.hash(password, passwordSalt));
            insert.setString(7, identitySalt);
            insert.setString(8, PasswordUtil.hash(demoIdentity, identitySalt));
            insert.executeUpdate();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 23505) throw new IllegalArgumentException("That voter ID is already registered.");
            throw ex;
        }
    }

    public static List<Voter> listVoters() throws SQLException {
        List<Voter> voters = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement query = connection.prepareStatement("""
                 SELECT id, username, full_name, date_of_birth FROM users WHERE role = 'VOTER' ORDER BY full_name
                 """);
             ResultSet rs = query.executeQuery()) {
            while (rs.next()) {
                String id = rs.getString("id");
                voters.add(new Voter(id, rs.getString("username"), rs.getString("full_name"),
                        rs.getDate("date_of_birth").toLocalDate(), getVotedElectionIds(connection, id)));
            }
        }
        return voters;
    }

    public static void removeVoter(String voterId) throws SQLException {
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement votes = connection.prepareStatement("SELECT COUNT(*) FROM votes WHERE voter_id = ?");
                 PreparedStatement delete = connection.prepareStatement("DELETE FROM users WHERE id = ? AND role = 'VOTER'")) {
                votes.setString(1, voterId);
                try (ResultSet rs = votes.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) > 0) throw new IllegalArgumentException("A voter cannot be removed after casting a ballot.");
                }
                delete.setString(1, voterId);
                if (delete.executeUpdate() == 0) throw new IllegalArgumentException("Voter was not found.");
                connection.commit();
            } catch (SQLException | RuntimeException ex) {
                connection.rollback();
                throw ex;
            }
        }
    }

    public static void createElection(String title, String description) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement insert = connection.prepareStatement(
                     "INSERT INTO elections (id, title, description, active) VALUES (?, ?, ?, TRUE)")) {
            insert.setString(1, UUID.randomUUID().toString());
            insert.setString(2, title.trim());
            insert.setString(3, description == null ? "" : description.trim());
            insert.executeUpdate();
        }
    }

    public static void addCandidate(String electionId, String name, String party, String details) throws SQLException {
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement election = connection.prepareStatement("SELECT active FROM elections WHERE id = ? FOR UPDATE");
                 PreparedStatement votes = connection.prepareStatement("SELECT COUNT(*) FROM votes WHERE election_id = ?");
                 PreparedStatement insert = connection.prepareStatement("""
                     INSERT INTO candidates (id, election_id, name, party, details) VALUES (?, ?, ?, ?, ?)
                     """)) {
                election.setString(1, electionId);
                try (ResultSet rs = election.executeQuery()) {
                    if (!rs.next() || !rs.getBoolean(1)) throw new IllegalArgumentException("Election is not open.");
                }
                votes.setString(1, electionId);
                try (ResultSet rs = votes.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) > 0) throw new IllegalArgumentException("Candidate management is locked after voting starts.");
                }
                insert.setString(1, UUID.randomUUID().toString());
                insert.setString(2, electionId);
                insert.setString(3, name.trim());
                insert.setString(4, party == null ? "" : party.trim());
                insert.setString(5, details == null ? "" : details.trim());
                insert.executeUpdate();
                connection.commit();
            } catch (SQLException | RuntimeException ex) {
                connection.rollback();
                throw ex;
            }
        }
    }

    public static void removeCandidate(String electionId, String candidateId) throws SQLException {
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement votes = connection.prepareStatement("SELECT COUNT(*) FROM votes WHERE election_id = ?");
                 PreparedStatement delete = connection.prepareStatement("DELETE FROM candidates WHERE election_id = ? AND id = ?")) {
                votes.setString(1, electionId);
                try (ResultSet rs = votes.executeQuery()) {
                    rs.next();
                    if (rs.getInt(1) > 0) throw new IllegalArgumentException("Candidates cannot be removed after voting starts.");
                }
                delete.setString(1, electionId);
                delete.setString(2, candidateId);
                if (delete.executeUpdate() == 0) throw new IllegalArgumentException("Candidate was not found.");
                connection.commit();
            } catch (SQLException | RuntimeException ex) {
                connection.rollback();
                throw ex;
            }
        }
    }

    public static void toggleElection(String electionId) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement update = connection.prepareStatement("UPDATE elections SET active = NOT active WHERE id = ?")) {
            update.setString(1, electionId);
            if (update.executeUpdate() == 0) throw new IllegalArgumentException("Election was not found.");
        }
    }

    public static List<Election> listElections(String voterId) throws SQLException {
        List<Election> elections = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement query = connection.prepareStatement("""
                 SELECT e.id, e.title, e.description, e.active,
                        (SELECT COUNT(*) FROM users u WHERE u.role = 'VOTER') AS eligible,
                        (SELECT COUNT(DISTINCT v.voter_id) FROM votes v WHERE v.election_id = e.id) AS turnout,
                        EXISTS (SELECT 1 FROM votes v WHERE v.election_id = e.id AND v.voter_id = ?) AS has_voted
                 FROM elections e ORDER BY e.created_at DESC
                 """)) {
            query.setString(1, voterId);
            try (ResultSet rs = query.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("id");
                    elections.add(new Election(id, rs.getString("title"), rs.getString("description"),
                            rs.getBoolean("active"), rs.getBoolean("has_voted"), rs.getInt("eligible"),
                            rs.getInt("turnout"), listCandidates(connection, id)));
                }
            }
        }
        return elections;
    }

    private static List<Candidate> listCandidates(Connection connection, String electionId) throws SQLException {
        List<Candidate> candidates = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement("""
                 SELECT c.id, c.name, c.party, c.details, COUNT(v.id) AS votes
                 FROM candidates c LEFT JOIN votes v ON v.candidate_id = c.id
                 WHERE c.election_id = ? GROUP BY c.id, c.name, c.party, c.details ORDER BY c.name
                 """)) {
            query.setString(1, electionId);
            try (ResultSet rs = query.executeQuery()) {
                while (rs.next()) candidates.add(new Candidate(rs.getString("id"), rs.getString("name"),
                        rs.getString("party"), rs.getString("details"), rs.getInt("votes")));
            }
        }
        return candidates;
    }

    public static String castVote(String voterId, String electionId, String candidateId) throws SQLException {
        String receipt = "BAL-" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement election = connection.prepareStatement("SELECT active FROM elections WHERE id = ? FOR UPDATE");
                 PreparedStatement candidate = connection.prepareStatement("SELECT id FROM candidates WHERE id = ? AND election_id = ?");
                 PreparedStatement insert = connection.prepareStatement("""
                     INSERT INTO votes (id, election_id, candidate_id, voter_id, receipt) VALUES (?, ?, ?, ?, ?)
                     """)) {
                election.setString(1, electionId);
                try (ResultSet rs = election.executeQuery()) {
                    if (!rs.next() || !rs.getBoolean(1)) throw new IllegalArgumentException("This election is closed or unavailable.");
                }
                candidate.setString(1, candidateId);
                candidate.setString(2, electionId);
                try (ResultSet rs = candidate.executeQuery()) {
                    if (!rs.next()) throw new IllegalArgumentException("The selected candidate is not in this election.");
                }
                insert.setString(1, UUID.randomUUID().toString());
                insert.setString(2, electionId);
                insert.setString(3, candidateId);
                insert.setString(4, voterId);
                insert.setString(5, receipt);
                insert.executeUpdate();
                connection.commit();
                return receipt;
            } catch (SQLException ex) {
                connection.rollback();
                if (ex.getErrorCode() == 23505) throw new IllegalArgumentException("A ballot has already been submitted for this election.");
                throw ex;
            } catch (RuntimeException ex) {
                connection.rollback();
                throw ex;
            }
        }
    }

    public static int countVoters() throws SQLException {
        try (Connection connection = getConnection(); Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM users WHERE role = 'VOTER'")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public static int countOpenElections() throws SQLException {
        try (Connection connection = getConnection(); Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM elections WHERE active = TRUE")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public static int countVotes() throws SQLException {
        try (Connection connection = getConnection(); Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT COUNT(*) FROM votes")) {
            rs.next();
            return rs.getInt(1);
        }
    }
}
