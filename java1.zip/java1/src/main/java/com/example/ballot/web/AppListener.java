package com.example.ballot.web;

import com.example.ballot.db.Database;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public final class AppListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent event) {
        try {
            Database.initialize();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to initialize the voting database.", ex);
        }
    }
}
