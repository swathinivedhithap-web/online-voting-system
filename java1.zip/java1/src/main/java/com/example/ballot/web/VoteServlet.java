package com.example.ballot.web;

import com.example.ballot.db.Database;
import com.example.ballot.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/vote")
public final class VoteServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.requireRole(request, response, "VOTER")) return;
        User user = Web.user(request);
        try {
            String electionId = Web.value(request, "electionId", 36);
            String candidateId = Web.value(request, "candidateId", 36);
            String receipt = Database.castVote(user.getId(), electionId, candidateId);
            Web.flash(request, "Your ballot has been recorded. Receipt: " + receipt + ". The receipt does not disclose your selection.", "success");
        } catch (IllegalArgumentException ex) {
            Web.flash(request, ex.getMessage(), "error");
        } catch (Exception ex) {
            throw new ServletException("Unable to record ballot.", ex);
        }
        response.sendRedirect(request.getContextPath() + "/voter");
    }
}
