package com.example.ballot.model;

import java.util.List;

public final class Election {
    private final String id;
    private final String title;
    private final String description;
    private final boolean active;
    private final boolean voterHasVoted;
    private final int eligibleVoters;
    private final int turnout;
    private final List<Candidate> candidates;

    public Election(String id, String title, String description, boolean active, boolean voterHasVoted,
                    int eligibleVoters, int turnout, List<Candidate> candidates) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.active = active;
        this.voterHasVoted = voterHasVoted;
        this.eligibleVoters = eligibleVoters;
        this.turnout = turnout;
        this.candidates = List.copyOf(candidates);
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public boolean isActive() { return active; }
    public boolean isVoterHasVoted() { return voterHasVoted; }
    public int getEligibleVoters() { return eligibleVoters; }
    public int getTurnout() { return turnout; }
    public List<Candidate> getCandidates() { return candidates; }
    public int getTotalVotes() { return candidates.stream().mapToInt(Candidate::getVotes).sum(); }
    public double getTurnoutPercent() {
        return eligibleVoters == 0 ? 0 : turnout * 100.0 / eligibleVoters;
    }
    public double getPercent(Candidate candidate) {
        int total = getTotalVotes();
        return total == 0 ? 0 : candidate.getVotes() * 100.0 / total;
    }
    public Candidate getLeader() {
        return candidates.stream().max((left, right) -> Integer.compare(left.getVotes(), right.getVotes())).orElse(null);
    }
    public boolean isTiedForLead() {
        Candidate leader = getLeader();
        return leader != null && candidates.stream().filter(c -> c.getVotes() == leader.getVotes()).count() > 1;
    }
}
