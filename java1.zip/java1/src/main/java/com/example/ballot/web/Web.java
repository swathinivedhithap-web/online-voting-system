package com.example.ballot.web;

import com.example.ballot.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

final class Web {
    private Web() { }

    static User user(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session == null ? null : (User) session.getAttribute("user");
    }

    static boolean requireRole(HttpServletRequest request, HttpServletResponse response, String role) throws IOException {
        User user = user(request);
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/");
            return false;
        }
        if (!role.equals(user.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return false;
        }
        return true;
    }

    static void flash(HttpServletRequest request, String message, String type) {
        HttpSession session = request.getSession();
        session.setAttribute("flashMessage", message);
        session.setAttribute("flashType", type);
    }

    static void consumeFlash(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) return;
        request.setAttribute("flashMessage", session.getAttribute("flashMessage"));
        request.setAttribute("flashType", session.getAttribute("flashType"));
        session.removeAttribute("flashMessage");
        session.removeAttribute("flashType");
    }

    static String value(HttpServletRequest request, String name, int maximumLength) {
        String value = request.getParameter(name);
        if (value == null) return "";
        value = value.trim();
        if (value.length() > maximumLength) throw new IllegalArgumentException(name + " is too long.");
        return value;
    }
}
