package com.example.ballot.model;

public final class Candidate {
    private final String id;
    private final String name;
    private final String party;
    private final String details;
    private final int votes;

    public Candidate(String id, String name, String party, String details, int votes) {
        this.id = id;
        this.name = name;
        this.party = party;
        this.details = details;
        this.votes = votes;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getParty() { return party; }
    public String getDetails() { return details; }
    public int getVotes() { return votes; }
}
