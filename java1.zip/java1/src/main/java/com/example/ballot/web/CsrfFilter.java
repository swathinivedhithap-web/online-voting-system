package com.example.ballot.web;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

@WebFilter("/*")
public final class CsrfFilter implements Filter {
    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setHeader("X-Content-Type-Options", "nosniff");
        httpResponse.setHeader("Referrer-Policy", "same-origin");
        httpResponse.setHeader("X-Frame-Options", "DENY");
        httpResponse.setHeader("Cache-Control", "no-store");

        if ("GET".equalsIgnoreCase(httpRequest.getMethod()) && !httpRequest.getRequestURI().contains("/assets/")) {
            HttpSession session = httpRequest.getSession(true);
            if (session.getAttribute("csrfToken") == null) {
                byte[] token = new byte[32];
                RANDOM.nextBytes(token);
                session.setAttribute("csrfToken", Base64.getUrlEncoder().withoutPadding().encodeToString(token));
            }
            httpRequest.setAttribute("csrfToken", session.getAttribute("csrfToken"));
        } else if ("POST".equalsIgnoreCase(httpRequest.getMethod())) {
            HttpSession session = httpRequest.getSession(false);
            String expected = session == null ? null : (String) session.getAttribute("csrfToken");
            String supplied = httpRequest.getParameter("csrfToken");
            if (expected == null || supplied == null
                    || !MessageDigest.isEqual(expected.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                                              supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8))) {
                httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "The form expired. Reload the page and try again.");
                return;
            }
        }
        chain.doFilter(request, response);
    }
}
