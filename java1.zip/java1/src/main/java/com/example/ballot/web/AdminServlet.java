package com.example.ballot.web;

import com.example.ballot.db.Database;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@WebServlet("/admin")
public final class AdminServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.requireRole(request, response, "ADMIN")) return;
        try {
            request.setAttribute("voters", Database.listVoters());
            request.setAttribute("elections", Database.listElections(null));
            request.setAttribute("voterCount", Database.countVoters());
            request.setAttribute("openElectionCount", Database.countOpenElections());
            request.setAttribute("totalBallots", Database.countVotes());
            Web.consumeFlash(request);
            request.getRequestDispatcher("/WEB-INF/views/admin_dashboard.jsp").forward(request, response);
        } catch (Exception ex) {
            throw new ServletException("Unable to load admin dashboard.", ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.requireRole(request, response, "ADMIN")) return;
        try {
            String action = Web.value(request, "action", 30);
            switch (action) {
                case "register-voter" -> {
                    String voterId = Web.value(request, "voterId", 80);
                    String name = Web.value(request, "fullName", 120);
                    String dobText = Web.value(request, "dateOfBirth", 10);
                    String demoIdentity = Web.value(request, "identityNumber", 12);
                    String password = request.getParameter("password");
                    if (voterId.isBlank() || name.isBlank()) throw new IllegalArgumentException("Voter ID and full name are required.");
                    if (!demoIdentity.matches("\\d{12}")) throw new IllegalArgumentException("Enter a 12-digit demo identity number.");
                    if (password == null || password.length() < 10 || password.length() > 200) {
                        throw new IllegalArgumentException("Set a temporary password of at least 10 characters.");
                    }
                    LocalDate dob;
                    try {
                        dob = LocalDate.parse(dobText);
                    } catch (DateTimeParseException ex) {
                        throw new IllegalArgumentException("Enter a valid date of birth.");
                    }
                    if (dob.isAfter(LocalDate.now()) || dob.isBefore(LocalDate.now().minusYears(120))) {
                        throw new IllegalArgumentException("Enter a valid date of birth.");
                    }
                    Database.registerVoter(voterId, name, dob, demoIdentity, password);
                    Web.flash(request, "Voter registered. The raw demo identity number is not stored.", "success");
                }
                case "create-election" -> {
                    String title = Web.value(request, "title", 140);
                    if (title.isBlank()) throw new IllegalArgumentException("Election title is required.");
                    Database.createElection(title, Web.value(request, "description", 500));
                    Web.flash(request, "Election created and opened. Add candidates before voting.", "success");
                }
                case "add-candidate" -> {
                    String name = Web.value(request, "candidateName", 100);
                    if (name.isBlank()) throw new IllegalArgumentException("Candidate name is required.");
                    Database.addCandidate(Web.value(request, "electionId", 36), name,
                            Web.value(request, "party", 100), Web.value(request, "details", 500));
                    Web.flash(request, "Candidate added.", "success");
                }
                case "remove-candidate" -> {
                    Database.removeCandidate(Web.value(request, "electionId", 36), Web.value(request, "candidateId", 36));
                    Web.flash(request, "Candidate removed.", "success");
                }
                case "remove-voter" -> {
                    Database.removeVoter(Web.value(request, "voterId", 36));
                    Web.flash(request, "Voter removed.", "success");
                }
                case "toggle-election" -> {
                    Database.toggleElection(Web.value(request, "electionId", 36));
                    Web.flash(request, "Election status updated.", "success");
                }
                default -> throw new IllegalArgumentException("Unknown admin action.");
            }
        } catch (IllegalArgumentException ex) {
            Web.flash(request, ex.getMessage(), "error");
        } catch (Exception ex) {
            throw new ServletException("Unable to complete admin action.", ex);
        }
        response.sendRedirect(request.getContextPath() + "/admin");
    }
}
