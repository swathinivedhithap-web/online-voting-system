package com.example.ballot.web;

import com.example.ballot.db.Database;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/results")
public final class ResultServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            request.setAttribute("elections", Database.listElections(null));
            request.getRequestDispatcher("/WEB-INF/views/results.jsp").forward(request, response);
        } catch (Exception ex) {
            throw new ServletException("Unable to load election results.", ex);
        }
    }
}
