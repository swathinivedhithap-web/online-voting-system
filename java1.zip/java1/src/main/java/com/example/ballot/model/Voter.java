package com.example.ballot.model;

import java.time.LocalDate;
import java.util.Set;

public final class Voter extends User {
    private final LocalDate dateOfBirth;
    private final Set<String> votedElectionIds;

    public Voter(String id, String voterId, String fullName, LocalDate dateOfBirth, Set<String> votedElectionIds) {
        super(id, voterId, fullName, "VOTER");
        this.dateOfBirth = dateOfBirth;
        this.votedElectionIds = Set.copyOf(votedElectionIds);
    }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public Set<String> getVotedElectionIds() { return votedElectionIds; }
    public boolean hasVoted(String electionId) { return votedElectionIds.contains(electionId); }
}
