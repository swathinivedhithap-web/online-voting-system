package com.example.ballot.web;

import com.example.ballot.db.Database;
import com.example.ballot.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/voter")
public final class VoterDashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (!Web.requireRole(request, response, "VOTER")) return;
        User user = Web.user(request);
        try {
            request.setAttribute("elections", Database.listElections(user.getId()));
            Web.consumeFlash(request);
            request.getRequestDispatcher("/WEB-INF/views/voter_dashboard.jsp").forward(request, response);
        } catch (Exception ex) {
            throw new ServletException("Unable to load voter dashboard.", ex);
        }
    }
}
