# Ballot — Tomcat voting-system demo

A Java 17 / Jakarta Servlet 6 web application packaged as a WAR for Apache Tomcat 10.1. H2 stores data in a local file; Maven downloads the application dependencies. The existing top-level `index.html` remains the original standalone browser demo.

## Requirements

- JDK 17 or newer (set `JAVA_HOME` and add its `bin` folder to `PATH`)
- Apache Maven 3.9+
- Apache Tomcat 10.1.x
- Google Chrome
- VS Code with **Extension Pack for Java** and **Community Server Connectors**

Tomcat 9 uses the older `javax.servlet` API and is not compatible with this project.

## Build and run

1. Open this project folder in VS Code.
2. Open the integrated terminal and confirm `java -version` and `mvn -version` both work.
3. Build the deployable application:

   ```powershell
   mvn clean package
   ```

   The deployable file will be `target\ROOT.war`. The WAR is named `ROOT` so Tomcat serves it from the server root URL.
4. In VS Code, open the **Community Server Connectors** view. Choose **Create New Server**, select the installed Tomcat 10.1 directory, and finish the wizard. If the view is hidden, open the Command Palette and run **Servers: Add Server**.
5. In the Servers view, right-click the Tomcat server and choose **Add Deployment**. Select `target\ROOT.war`.
6. Right-click the server and choose **Start**. Wait for the server status to become Started.
7. Open Chrome at **http://localhost:8080/**.

Alternatively, deploy `target\ROOT.war` by copying it into Tomcat's `webapps` folder and starting Tomcat. To open Chrome from PowerShell after the server is running:

```powershell
Start-Process "chrome.exe" "http://localhost:8080/"
```

The initial demo admin credentials are **admin / admin123**. The first server startup creates this account automatically.

## Data location

H2 creates its database outside the deployed application at:

```text
%USERPROFILE%\.ballot-demo\voting.mv.db
```

To choose another H2 database file, start Tomcat with the Java system property `-Dballot.db.path=C:/path/to/voting` (omit the `.mv.db` suffix). Keep the database directory private and backed up appropriately.

## Included features

- Admin and voter sign-in, session fixation protection, CSRF tokens, and role checks.
- Admin registration of voters, with date-of-birth age check, and voter/election/candidate management.
- Transactional ballot insertion with a database unique constraint on `(election_id, voter_id)`.
- Receipt IDs, live vote percentages, leading-candidate/tie display, and turnout.
- PBKDF2-HMAC-SHA256 salted hashes for passwords and the demo identity number.

## Important limitations

This is an educational/local prototype, **not an election-ready system**. The 12-digit identity field is only compared with a locally registered demo value; there is no Aadhaar/UIDAI integration or identity proofing. Do not enter real Aadhaar numbers or passwords. The sample admin password is intentionally known and must not be used on a network-facing deployment. H2 file storage and the app itself do not provide the independent auditing, ballot secrecy guarantees, operational controls, or security review required for a real election. The database associates each ballot with a voter to enforce the one-vote rule; this prototype does not implement cryptographic ballot anonymity.
